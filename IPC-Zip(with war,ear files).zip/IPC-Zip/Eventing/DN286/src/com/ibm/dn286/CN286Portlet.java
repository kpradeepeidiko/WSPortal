package com.ibm.dn286;

import java.io.*;
import javax.portlet.*;
import javax.xml.namespace.QName;

/**
 * A sample portlet based on GenericPortlet
 */
public class CN286Portlet extends GenericPortlet {

	public static final String JSP_FOLDER    = "/_CN286/jsp/";    // JSP folder name

	public static final String VIEW_JSP      = "CN286PortletView";         // JSP file name to be rendered on the view mode
	public static final String SESSION_BEAN  = "CN286PortletSessionBean";  // Bean name for the portlet session
	public static final String FORM_SUBMIT   = "CN286PortletFormSubmit";   // Action name for submit form
	public static final String FORM_TEXT     = "CN286PortletFormText";     // Parameter name for the text input

	private String stockValue = "";

	 
	/**
	 * @see javax.portlet.Portlet#init()
	 */
	public void init() throws PortletException{
		super.init();
	}

	/**
	 * Serve up the <code>view</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());

		// Check if portlet session exists
		/*CN286PortletSessionBean sessionBean = getSessionBean(request);
		if( sessionBean==null ) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}*/
		
		request.setAttribute("symbol", stockValue);

		// Invoke the JSP to render
		//System.out.println("CN286_DView::: URL === " + getJspFilePath(request, VIEW_JSP) );
		System.out.println("CN286_DView::: Value === " + stockValue);
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, VIEW_JSP));
		rd.include(request,response);
	}

	/**
	 * Process an action request.
	 * 
	 * @see javax.portlet.Portlet#processAction(javax.portlet.ActionRequest, javax.portlet.ActionResponse)
	 */
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		/*if( request.getParameter(FORM_SUBMIT) != null ) {
			// Set form text in the session bean
			CN286PortletSessionBean sessionBean = getSessionBean(request);
			if( sessionBean != null )
				sessionBean.setFormText(request.getParameter(FORM_TEXT));
		}*/
		QName qName = new QName("http://CN286.com", "CN2ON");	
		response.setEvent(qName, stockValue);
		System.out.println("CN286_PA ::: Value === " + stockValue);
	}

	
	@Override
	public void processEvent(EventRequest request, EventResponse response)
			throws PortletException, IOException {
		super.processEvent(request, response);
		stockValue = request.getEvent().getValue().toString();
		System.out.println("CN286_PE ::: Value === " + stockValue);
		response.setRenderParameter("symbol", stockValue);
	}
	
	
	/**
	 * Get SessionBean.
	 * 
	 * @param request PortletRequest
	 * @return CN286PortletSessionBean
	 */
	@SuppressWarnings("unused")
	private static CN286PortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if( session == null )
			return null;
		CN286PortletSessionBean sessionBean = (CN286PortletSessionBean)session.getAttribute(SESSION_BEAN);
		if( sessionBean == null ) {
			sessionBean = new CN286PortletSessionBean();
			session.setAttribute(SESSION_BEAN,sessionBean);
		}
		return sessionBean;
	}

	/**
	 * Process a serve Resource request.
	 * 
	 * @see javax.portlet.Portlet#serveResource(javax.portlet.ResourceRequest, javax.portlet.ResourceResponse)
	 */
	public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, java.io.IOException {
		String resourceID = request.getResourceID();
		if (resourceID.equals("resourceID")) {
			// Insert code for serving the resource 
		}
	}

	/**
	 * Returns JSP file path.
	 * 
	 * @param request Render request
	 * @param jspFile JSP file name
	 * @return JSP file path
	 */
	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if( markup == null )
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}

	/**
	 * Convert MIME type to markup name.
	 * 
	 * @param contentType MIME type
	 * @return Markup name
	 */
	private static String getMarkup(String contentType) {
		if( "text/vnd.wap.wml".equals(contentType) )
			return "wml";
        else
            return "html";
	}

	/**
	 * Returns the file extension for the JSP file
	 * 
	 * @param markupName Markup name
	 * @return JSP extension
	 */
	private static String getJspExtension(String markupName) {
		return "jsp";
	}

}
